/**
 * Grooming HQ — one-click menu for the Dog Grooming Business Spreadsheet v2.
 *
 * GOOGLE SHEETS ONLY. This file uses Google Apps Script, which Excel does
 * not run. In Excel, do the same jobs by hand (the setup guide shows how).
 *
 * Install: in Google Sheets, Extensions > Apps Script, delete anything in
 * Code.gs, paste this whole file, save, refresh the spreadsheet. A
 * "Grooming HQ" menu appears at the top.
 *
 * Written against the v2 layout — exact sheet names and columns:
 *   Appointments: A ID, B Date, C Time, D Pet, E Owner, F Service, G Size,
 *     H Coat, I Matting, J Add-ons, K Base, L Extras, M Total, N Minutes,
 *     O Status, P Groomer, Q Deposit held, R Deposit needed, S Notes
 *   Clients & Pets: B Pet, S Deposit needed ("Yes"/"No")
 *   Rebooking Tracker: A Pet, E Next due
 *   No-Show Log: A Appt ID, B Date, C Pet, D Owner, E Service,
 *     F Booked price, G Type, H Fee, I Deposit kept, J Lost, K Rebooked, L Notes
 *   Report Card: B4 = pet name
 *   Start Here: B13 = currency picker (named CurrencyCode)
 */

function onOpen() {
  SpreadsheetApp.getUi().createMenu('Grooming HQ')
    .addItem('Book next groom', 'bookNextGroom')
    .addItem('Mark no-show', 'markNoShow')
    .addItem('Mark late cancel', 'markLateCancel')
    .addItem('Save Report Card as PDF', 'saveReportCardPdf')
    .addSeparator()
    .addItem('Start fresh (clear sample data)', 'startFresh')
    .addItem('Set currency', 'setCurrency')
    .addToUi();
}

function findTotalsRow(sheet) {
  var vals = sheet.getRange('A1:A' + sheet.getLastRow()).getValues();
  for (var i = 0; i < vals.length; i++) {
    if (vals[i][0] === 'TOTALS') return i + 1;
  }
  return sheet.getLastRow() + 1;
}

/** Insert a row just above the TOTALS row (or at the end) and fill it. */
function insertBeforeTotals(sheet, values) {
  var row = findTotalsRow(sheet);
  if (row <= sheet.getLastRow()) {
    sheet.insertRowBefore(row);
  } else {
    row = sheet.getLastRow() + 1;
  }
  sheet.getRange(row, 1, 1, values.length).setValues([values]);
  return row;
}

/** Book the dog's next groom on its due date from the Rebooking Tracker. */
function bookNextGroom() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var ui = SpreadsheetApp.getUi();
  var resp = ui.prompt('Book next groom',
    'Which dog? Type the pet name exactly as it appears on the Clients & Pets tab:',
    ui.ButtonSet.OK_CANCEL);
  if (resp.getSelectedButton() !== ui.Button.OK) return;
  var pet = resp.getResponseText().trim();
  if (!pet) return;

  var rb = ss.getSheetByName('Rebooking Tracker');
  var pets = rb.getRange('A5:A' + rb.getLastRow()).getValues();
  var rbRow = -1;
  for (var i = 0; i < pets.length; i++) {
    if (pets[i][0] === pet) { rbRow = 5 + i; break; }
  }
  if (rbRow === -1) {
    ui.alert('No dog named "' + pet + '" on the Rebooking Tracker. Check the spelling.');
    return;
  }
  var due = rb.getRange(rbRow, 5).getValue(); // next due date

  var ap = ss.getSheetByName('Appointments');
  var rows = ap.getRange(5, 1, ap.getLastRow() - 4, 19).getValues();
  var maxId = 0;
  var lastAppt = null;
  for (var k = 0; k < rows.length; k++) {
    var n = parseInt(String(rows[k][0]).replace(/\D/g, ''), 10);
    if (!isNaN(n) && n > maxId) maxId = n;
    if (rows[k][3] === pet) lastAppt = rows[k];
  }
  if (!lastAppt) {
    ui.alert('No past appointment found for "' + pet + '". Book the first groom by typing a row on the Appointments tab.');
    return;
  }

  // $20 deposit if the dog needs one (2+ no-shows / late cancels in 12 months).
  var dep = 0;
  var cp = ss.getSheetByName('Clients & Pets');
  var cpPets = cp.getRange('B5:B' + cp.getLastRow()).getValues();
  for (var m = 0; m < cpPets.length; m++) {
    if (cpPets[m][0] === pet) {
      dep = cp.getRange(5 + m, 19).getValue() === 'Yes' ? 20 : 0;
      break;
    }
  }

  var newId = 'A' + String(maxId + 1).padStart(3, '0');
  var totalsRow = findTotalsRow(ap);
  ap.insertRowBefore(totalsRow);
  // Copy the row above (formulas + formatting), then fill in only the
  // white input cells — the green formula cells keep working.
  ap.getRange(totalsRow - 1, 1, 1, 19).copyTo(ap.getRange(totalsRow, 1, 1, 19));
  ap.getRange(totalsRow, 1).setValue(newId);
  ap.getRange(totalsRow, 2).setValue(due);
  ap.getRange(totalsRow, 3).setValue(lastAppt[2] || '9:00 AM');
  ap.getRange(totalsRow, 4).setValue(pet);
  ap.getRange(totalsRow, 6).setValue(lastAppt[5]);  // service
  ap.getRange(totalsRow, 8).setValue(lastAppt[7]);  // coat
  ap.getRange(totalsRow, 9).setValue(lastAppt[8]);  // matting
  ap.getRange(totalsRow, 10).setValue(lastAppt[9]); // add-ons
  ap.getRange(totalsRow, 15).setValue('Scheduled');
  ap.getRange(totalsRow, 16).setValue(lastAppt[15]); // groomer
  ap.getRange(totalsRow, 17).setValue(dep);
  ap.getRange(totalsRow, 19).setValue('');
  ss.toast('Booked ' + pet + ' for ' + due + ' (' + newId + ').'
    + (dep ? ' $20 deposit held.' : ''), 'Grooming HQ');
}

function markNoShow() { markAs('No-show'); }
function markLateCancel() { markAs('Late cancel'); }

/**
 * Mark the appointment on the active row as a no-show (50% of the booked
 * price) or a late cancel (25%). Writes a row to the No-Show Log with the
 * fee, the deposit kept toward it, and the money lost.
 * Click any cell on the appointment's row first.
 */
function markAs(type) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getActiveSheet();
  if (sheet.getName() !== 'Appointments') {
    SpreadsheetApp.getUi().alert('Click a cell on an appointment row on the Appointments tab first, then use this menu.');
    return;
  }
  var row = ss.getActiveCell().getRow();
  if (row < 5) {
    SpreadsheetApp.getUi().alert('Click a cell on an appointment row (row 5 or below) first.');
    return;
  }
  var vals = sheet.getRange(row, 1, 1, 19).getValues()[0];
  var id = vals[0];
  var status = vals[14];
  if (status === 'No-show' || status === 'Late cancel') {
    SpreadsheetApp.getUi().alert(id + ' is already marked ' + status + '.');
    return;
  }
  var total = vals[12];
  if (typeof total !== 'number') {
    SpreadsheetApp.getUi().alert('That row has no price yet — fill in the pet and service first.');
    return;
  }
  var rate = type === 'No-show' ? 0.5 : 0.25;
  var fee = Math.round(total * rate * 100) / 100;
  var depositHeld = vals[16] || 0;
  var kept = Math.min(depositHeld, fee);
  var lost = Math.round((total - fee) * 100) / 100;
  sheet.getRange(row, 15).setValue(type);
  var ns = ss.getSheetByName('No-Show Log');
  insertBeforeTotals(ns, [id, vals[1], vals[3], vals[4], vals[5], total,
    type, fee, kept, lost, 'No', '']);
  ss.toast(id + ' marked ' + type + '. Fee ' + fee + ' (deposit kept ' + kept
    + ', lost ' + lost + ').', 'Grooming HQ');
}

/** Save the Report Card sheet as a PDF in Google Drive. */
function saveReportCardPdf() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName('Report Card');
  var pet = sheet.getRange('B4').getValue();
  var url = 'https://docs.google.com/spreadsheets/d/' + ss.getId()
    + '/export?exportFormat=pdf&format=pdf&gid=' + sheet.getSheetId()
    + '&portrait=true&fitw=true'
    + '&top_margin=0.5&bottom_margin=0.5&left_margin=0.5&right_margin=0.5';
  var token = ScriptApp.getOAuthToken();
  var blob = UrlFetchApp.fetch(url, {
    headers: { Authorization: 'Bearer ' + token }
  }).getBlob().setName('Report Card - ' + pet + '.pdf');
  var file = DriveApp.createFile(blob);
  ss.toast('Saved "' + file.getName() + '" to your Google Drive.', 'Report Card');
}

/**
 * Clear the sample rows everywhere, leaving one blank template row (row 5)
 * with its formulas. Prices on the Price Matrix and your goals stay put.
 * A green cell may show #N/A until you type the first row — that is normal,
 * it clears once the row is filled in.
 */
function startFresh() {
  var ui = SpreadsheetApp.getUi();
  var ok = ui.alert('Start fresh?',
    'This clears the sample rows on every tab and leaves one blank template row with the formulas. Your prices on the Price Matrix stay as they are. This cannot be undone.',
    ui.ButtonSet.YES_NO);
  if (ok !== ui.Button.YES) return;
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  // [sheet, first data row, input columns to clear on the template row]
  var plan = [
    ['Clients & Pets', 5, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]],
    ['Grooming Profiles', 5, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]],
    ['Appointments', 5, [1, 2, 3, 4, 6, 8, 9, 10, 15, 16, 17, 19]],
    ['Payments & Invoices', 5, [1, 2, 3, 4, 5, 7, 8, 9]],
    ['Expenses', 5, [1, 2, 3, 4, 5, 6]],
    ['Mileage Log', 7, [1, 2, 3, 4]],
    ['Inventory', 5, [1, 2, 3, 4, 5, 6]],
    ['Equipment', 5, [1, 2, 3, 4, 5, 8]],
    ['No-Show Log', 5, [1, 7, 11, 12]],
    ['Pet Club Loyalty', 5, [3]],
    ['Service Profit', 5, [1, 2, 3, 4]]
  ];
  plan.forEach(function (item) {
    var sheet = ss.getSheetByName(item[0]);
    if (!sheet) return;
    var first = item[1];
    var last = sheet.getLastRow();
    var totals = findTotalsRow(sheet);
    // Data ends just above the TOTALS row; on sheets without one, the last
    // row is the note, so data ends one row above it.
    var dataEnd = (totals <= last) ? totals - 1 : last - 1;
    if (dataEnd > first) sheet.deleteRows(first + 1, dataEnd - first);
    item[2].forEach(function (col) { sheet.getRange(first, col).clearContent(); });
  });
  ss.toast('Sample data cleared. Type your first dog on row 5 of Clients & Pets — the green cells fill themselves in.', 'Grooming HQ');
}

/**
 * Set the workbook currency. Writes the code to Start Here B13 (the
 * CurrencyCode cell) and rewrites every money number format in the
 * workbook, so $ becomes C$, £, € or A$ everywhere.
 */
function setCurrency() {
  var ui = SpreadsheetApp.getUi();
  var resp = ui.prompt('Set currency',
    'Type a currency code: USD, CAD, GBP, EUR or AUD', ui.ButtonSet.OK_CANCEL);
  if (resp.getSelectedButton() !== ui.Button.OK) return;
  var code = resp.getResponseText().trim().toUpperCase();
  var symbols = { USD: '$', CAD: 'C$', GBP: '\u00A3', EUR: '\u20AC', AUD: 'A$' };
  if (!symbols[code]) {
    ui.alert('Unknown currency "' + code + '". Use USD, CAD, GBP, EUR or AUD.');
    return;
  }
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  ss.getSheetByName('Start Here').getRange('B13').setValue(code);
  var sym = symbols[code];
  ss.getSheets().forEach(function (sheet) {
    var range = sheet.getDataRange();
    var fmts = range.getNumberFormats();
    var changed = false;
    for (var i = 0; i < fmts.length; i++) {
      for (var j = 0; j < fmts[i].length; j++) {
        var f = fmts[i][j];
        if (f && f.indexOf('$') !== -1) {
          fmts[i][j] = f.replace(/^"[^"]*"/, '"' + sym + '"');
          changed = true;
        }
      }
    }
    if (changed) range.setNumberFormats(fmts);
  });
  ss.toast('Currency set to ' + code + ' (' + sym + '). Money cells now show ' + sym + '.', 'Grooming HQ');
}
